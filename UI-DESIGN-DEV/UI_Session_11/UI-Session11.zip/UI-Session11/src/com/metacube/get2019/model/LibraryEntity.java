package com.metacube.get2019.model;
/**
 * @author Vertika
 */
public class LibraryEntity {

	private int id;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id=id;
	}
}
