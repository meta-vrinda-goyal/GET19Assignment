package com.metacube.get2019.dao;

import java.sql.SQLException;
import java.util.List;

import com.metacube.get2019.model.*;

/**
 * @author Vertika
 */
public interface BaseDao {
	
	/**
	 * This method is used to retrieve all books
	 * @param query is the query to retrieve all books.
	 * @return List of the retrieved books 
	 * @throws SQLException
	 */
	List<Book> getAllBooks(String query);
	/**
	 * This method is used to retrieve book by title
	 * @param query is the query to retrieve book by title
	 * @param bookTitle is the title of the book to be retrieved
	 * @return Book retrieved
	 */
	Book getBookByTitle(String query, String bookTitle);
	/**
	 * This method is used to delete all books
	 * @param query is the query to delete all books
	 * @return true or false
	 */
	boolean deleteAllBooks(String query);
	/**
	 * This method is used to delete book by id
	 * @param query is the query to delete the book by id
	 * @param bookId of the book to be deleted
	 * @return
	 */
	boolean deleteBookById(String query, int bookId);
	/**
	 * This method is used to update library by title and published year
	 * @param query is the query to update library 
	 * @param book is the book on which the updation is to be performed
	 * @return true or false
	 */
	boolean updateBook(String query, Book book);
	
	
}
