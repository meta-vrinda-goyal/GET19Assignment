package com.metacube.get2019.controller;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import javax.ws.rs.DELETE;

import com.metacube.get2019.facade.LibraryFacade;

@Path("/library")
public class LibraryController {

	/**
	 * This method is used to retrieve all books.
	 * @return json string of the retrieved books
	 * @throws SQLException
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllFruits() throws SQLException
	{
		String response=LibraryFacade.getBooks();
		return response;
	}
	
	/**
	 * This method is used to Retrieve book by title
	 * @param bookTitle is the title of the book to be retrieved 
	 * @return json string of the retrieved book
	 * @throws SQLException
	 */
	@GET
	@Path("{bookTitle}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getBookByTitle(@PathParam("bookTitle") String bookTitle) throws SQLException
	{
		System.out.println(bookTitle);
		String response=LibraryFacade.getBookByTitle(bookTitle);
		return response;
	}
	
	/**
	 * This method is used to Delete all books
	 * @return text if the deletion has been performed successfully
	 */
	@DELETE
	@Produces(MediaType.TEXT_HTML)
	public String deleteLibrary(){
		String response=LibraryFacade.deleteLibrary();
		return response;
	}
	
	/**
	 * This method is used to delete book by Id
	 * @param bookId is the book id of the book to be deleted
	 * @return text if the deletion has been performed successfully
	 * @throws SQLException
	 */
	@DELETE
	@Path("{bookId}")
	@Produces(MediaType.TEXT_HTML)
	public String deleteBookById(@PathParam("bookId") int bookId) throws SQLException{
		String response=LibraryFacade.deleteBookById(bookId);
		return response;
	}
	/**
	 * This method is used to create a new book record
	 * @param jsonString is the input json 
	 * @return text if the insertion has been performed successfully
	 */
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_HTML)
	public String postBook(String jsonString){
		String response=LibraryFacade.postBook(jsonString);
		return response;
		
	}
	
	/**
	 * This method is used to Update book by title and published year
	 * @param jsonString is the input json in the body of the put request
	 * @return text if the updation has been performed successfully
	 */
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_HTML)
	public String putBook(String jsonString){
		String response=LibraryFacade.updateBook(jsonString);
		return response;
		
	}
	
	

}
